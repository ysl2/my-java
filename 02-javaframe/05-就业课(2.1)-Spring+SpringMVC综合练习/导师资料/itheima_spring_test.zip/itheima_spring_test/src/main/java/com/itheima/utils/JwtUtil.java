package com.itheima.utils;

import io.jsonwebtoken.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JwtUtil {


    public static final long EXPIRATION_TIME = 3600000000L; // 1000 hour
    static final String SECRET = "ThisIsASecret";
    static final String TOKEN_PREFIX = "Bearer";

    public static String generateToken(Long userId, Date generateTime) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        //可以把任何安全的数据放到map里面
        map.put("userId", userId);
        map.put("generateTime", generateTime);
        String jwt = Jwts.builder()
                .setClaims(map)
                .setExpiration(new Date(generateTime.getTime() + EXPIRATION_TIME))
                .signWith(SignatureAlgorithm.HS256, SECRET)
                .compact();
        return jwt;
    }

    /**
     * @param token
     * @return
     */
    public static Map<String, Object> validateToken(String token) {
        Map<String, Object> resp = new HashMap<String, Object>();
        if (token != null) {
            // 解析token
            try {
                Map<String, Object> body = Jwts.parser()
                        .setSigningKey(SECRET)
                        .parseClaimsJws(token.replace(TOKEN_PREFIX, ""))
                        .getBody();
                Object userId = body.get("userId");
                Date generateTime = new Date((Long) body.get("generateTime"));

                if (userId == null) {
                    resp.put("ERR_MSG", "解析的信息为空");
                    return resp;
                }
                resp.put("userId", userId);
                resp.put("generateTime", generateTime);
                resp.put("ERR_MSG","SUCCESS");
                return resp;
            } catch (SignatureException e) {
                // TODO: handle exception
                // don't trust the JWT!
                // jwt 解析错误
                resp.put("ERR_MSG", "解析错误");
                return resp;
            } catch (ExpiredJwtException e) {
                // TODO: handle exception
                // jwt 已经过期，在设置jwt的时候如果设置了过期时间，这里会自动判断jwt是否已经过期，如果过期则会抛出这个异常，我们可以抓住这个异常并作相关处理。
                resp.put("ERR_MSG", "token过期");
                return resp;
            }
        } else {
            resp.put("ERR_MSG", "token为空");
            return resp;
        }
    }

}
