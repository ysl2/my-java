package com.itheima.mapper;

import com.itheima.domain.Order;

import java.util.List;

public interface OrderMapper {

    //查询全部的方法
    public List<Order> findAll();

}
