package com.itheima.service;

public interface AccountService {

    public void transfer(String outMan, String inMan, double money);

}
