package com.itheima.proxy.cglib;


public class Target {
    public void save() {
        System.out.println("save running.....");
    }
}
