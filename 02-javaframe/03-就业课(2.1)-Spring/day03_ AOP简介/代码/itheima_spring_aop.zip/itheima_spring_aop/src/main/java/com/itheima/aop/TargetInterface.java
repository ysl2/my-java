package com.itheima.aop;

public interface TargetInterface {

    public void save();

}
