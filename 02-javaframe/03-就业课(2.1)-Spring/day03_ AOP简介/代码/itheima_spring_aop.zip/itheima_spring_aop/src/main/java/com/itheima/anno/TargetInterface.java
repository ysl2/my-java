package com.itheima.anno;

public interface TargetInterface {

    public void save();

}
