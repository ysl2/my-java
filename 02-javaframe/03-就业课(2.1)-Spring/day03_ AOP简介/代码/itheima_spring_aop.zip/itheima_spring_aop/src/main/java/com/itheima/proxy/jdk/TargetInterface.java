package com.itheima.proxy.jdk;

public interface TargetInterface {

    public void save();

}
