({
  type: 'div',
  children: [{
    type: 'div',
    classList: ['box', 'box1']
  }, {
    type: 'div',
    classList: ['box', 'box2']
  }, {
    type: 'div',
    classList: ['box', 'box3']
  }, {
    type: 'div',
    classList: ['box', 'box4']
  }, {
    type: 'div',
    classList: ['box', 'box5']
  }]
})
