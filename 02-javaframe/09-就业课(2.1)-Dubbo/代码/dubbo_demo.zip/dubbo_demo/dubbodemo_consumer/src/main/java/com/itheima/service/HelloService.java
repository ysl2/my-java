package com.itheima.service;

public interface HelloService {
    public String sayHello(String name);
}
